
$(function(){dotclear.hideLockable();var tbCategory=new jsToolBar(document.getElementById('cat_desc'));tbCategory.draw('xhtml');});